package com.company;

public class Horse extends  Animal{
    Horse(int age,String name,String colour,int value){
        super(age,name,colour,value);
    }

    @Override
    public String run(int value){

    }

    @Override
    public String jumpOver(int value){

    }

    @Override
    public String swim(int value){

    }
}

